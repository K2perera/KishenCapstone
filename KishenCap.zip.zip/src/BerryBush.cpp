#include "BerryBush.h"
#include <iostream>
#include "SDL.h"

void Obstacle:: placeObstacle(){
  SDL_Point P;
  
  for(int i = 0; i < grid_width/2; i++) {
      P.x = i + (grid_width/4);
      P.y = grid_height/3;
      obstaclePoints.push_back(P);
  }

  for(int i = 0; i < grid_width/2; i++) {
      P.x = i + (grid_width/4);
      P.y = 2*(grid_height/3);
      obstaclePoints.push_back(P);
  }
}

 std::vector<SDL_Point> Obstacle:: get_obstecle() {
     return obstaclePoints;
 }

 bool Obstacle::ObstacleCell(int x, int y) {
  for (auto const &item : obstaclePoints) {
    if (x == item.x && y == item.y) {
      return true;
    }
  }
  return false;
}