#include <iostream>
#include "controller.h"
#include "game.h"
#include "renderer.h"
#include "obstack.h"

int main() {
   std::size_t kFramesPerSecond{60};
   std::size_t kMsPerFrame{1000 / kFramesPerSecond};
   std::size_t kScreenWidth{640};
   std::size_t kScreenHeight{640};
   std::size_t kGridWidth{32};
   std::size_t kGridHeight{32}; 
  
  // changing launch options 
  std::cout << "Do you want to change the launch options (size of screen and grid) of this game? If you do, type \"yes\" without the quotes and press Enter.";
  std::string answer;
  getline(std::cin, answer); //handle empty inputs]
  if (answer == "yes") {
    std::cout << "Screen width: ";
    std::cin >> kScreenWidth;
    std::cout << "Screen height: ";
    std::cin >> kScreenHeight;
    std::cout << "Grid width: ";
    std::cin >> kGridWidth;
    std::cout << "Grid height: ";
    std::cin >> kGridHeight;
  }

  Obstacle obstacle(kGridWidth, kGridHeight);
  Renderer renderer(kScreenWidth, kScreenHeight, kGridWidth, kGridHeight,obstacle);
  Controller controller;
  Game game(kGridWidth, kGridHeight, obstacle);
  game.Run(controller, renderer, kMsPerFrame);
  std::cout << "Nice Try\n"; //confirms that game terminated successfully
  
  if(game.GetScore() > 10) {
    std::cout << "Congrats! You got a score of: " <<game.GetScore() <<"\n";  //to reward good scores 
  } else {
    std::cout << "Score: " << game.GetScore() << "\n"; 
  }
  
  std::cout << "Size: " << game.GetSize() << "\n";
  return 0;
}